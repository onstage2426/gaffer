<?php

declare(strict_types=1);

namespace GafferSearch\Cli;

use GafferSearch\Services\IndexBusyException;
use GafferSearch\Services\IndexRegistry;
use GafferSearch\Services\IndexService;
use WP_CLI;

/**
 * `wp gaffer-search rebuild [<index>]` — rebuild one index, or every registered index, in full: every
 * language's file, then (with GAFFER_SEARCH_SNAPSHOT_DIR) published for the other web servers. For a
 * system cron instead of WP-cron, and after a deploy. Exits non-zero when a build is already
 * running or fails.
 *
 * @internal Not part of the public API (see API.md): may change in any version.
 */
final class RebuildCommand
{
    public function __construct(
        private readonly IndexService $index,
        private readonly IndexRegistry $registry,
    ) {}

    /**
     * Rebuild an index in full: every language's file, then published for the other web servers.
     *
     * ## OPTIONS
     *
     * [<index>]
     * : The index name. Default: every registered index.
     *
     * ## EXAMPLES
     *
     *     wp gaffer-search rebuild products
     *
     * @param list<string> $args
     */
    public function __invoke(array $args): void
    {
        $names = isset($args[0]) ? [$args[0]] : $this->registry->names();
        foreach ($names as $name) {
            if (!$this->registry->has($name)) {
                WP_CLI::error("No index registered as '{$name}'. Registered: " . implode(', ', $this->registry->names()));
            }
            $start = microtime(true);
            try {
                $count = $this->index->build($name)[$name] ?? 0;
            } catch (IndexBusyException $e) {
                if ($e->elsewhere) {
                    // Not a failure: this server imports it on its next `wp gaffer-search update`.
                    WP_CLI::warning("{$name}: already being rebuilt on another server; skipped.");
                    continue;
                }
                WP_CLI::error("{$name}: already being rebuilt.");
                return;
            }
            WP_CLI::log(sprintf('%s: %d documents in %.1fs.', $name, $count, microtime(true) - $start));
        }
    }
}
