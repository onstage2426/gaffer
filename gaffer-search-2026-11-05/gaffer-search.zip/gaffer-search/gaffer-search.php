<?php

declare(strict_types=1);

/**
 * Plugin Name: Gaffer Search
 * Description: Fast full-text search for WordPress, powered by Fuzor.
 * Version: 0.0.0+f5884e7
 * Requires PHP: 8.5
 * Requires at least: 6.0
 * Text Domain: gaffer-search
 * Plugin URI: https://github.com/onstage2426/gaffer-search
 * Update URI: https://github.com/onstage2426/gaffer-search
 * Author: onstage2426
 * Author URI: https://github.com/onstage2426
 */

defined("ABSPATH") || exit();

require_once __DIR__ . "/vendor/autoload.php";

use GafferSearch\Bootstrap;
use GafferSearch\WpHubUpdater\Plugin\PluginUpdater;

PluginUpdater::build("https://github.com/onstage2426/gaffer-search", __FILE__)
    ->setReleaseVersionFilter("/^0\./", PluginUpdater::RELEASE_FILTER_ALL)
    ->throttleRedundantChecks(hours: 72)
    ->setCooldown(hours: 0)
    // The repository is private until it goes public: a read-only token (Contents: Read on this
    // repository only), expires 2026-12-04.
    ->setAccessToken(token: "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")
    ->enableAutoUpdates();

$bootstrap = new Bootstrap(__FILE__);
register_activation_hook(__FILE__, $bootstrap->activate(...));
register_deactivation_hook(__FILE__, [Bootstrap::class, "deactivate"]);
add_action("plugins_loaded", fn() => $bootstrap->init(), 20);
