<?php

declare(strict_types=1);

namespace GafferSearch\Support;

use Fuzor\FacetExclude;
use Fuzor\FacetRange;

/**
 * Parses the plugin's filter[] contract into the shape Fuzor\Index::search()/searchBoolean()/
 * facetSearch() expect, and serializes that shape back for signing into a token.
 *
 *   filter[field]=value                         — exact string match
 *   filter[field][]=Casio&filter[field][]=Seiko — OR across multiple string values
 *   filter[field][min]=x&filter[field][max]=y   — numeric range (Fuzor\FacetRange)
 *   filter[field][not]=value                    — exclusion (Fuzor\FacetExclude)
 *   filter[field][not][]=a&filter[field][not][]=b
 *   filter[field][not][min]=x&…[not][max]=y      — excluded numeric range
 *
 * The same array shape is what a signed token's locked `filter` holds, so one parser serves
 * the HTTP endpoints, tokens, and searches from PHP (server-side rendering) alike.
 *
 * @internal Not part of the public API (see API.md): may change in any version.
 */
final class FilterQuery
{
    /**
     * @param  array<mixed> $raw
     * @return array<string, string|list<string>|FacetRange|FacetExclude>
     */
    public static function parse(array $raw): array
    {
        $filter = [];

        foreach ($raw as $field => $value) {
            $field = (string) preg_replace('/[^a-z0-9_]/i', '', (string) $field);
            if ($field === '') {
                continue;
            }

            if (is_array($value) && array_key_exists('not', $value)) {
                $excluded = self::parseValue($value['not']);
                if ($excluded !== null) {
                    $filter[$field] = new FacetExclude($excluded);
                }
                continue;
            }

            $parsed = self::parseValue($value);
            if ($parsed !== null) {
                $filter[$field] = $parsed;
            }
        }

        return $filter;
    }

    /**
     * Inverse of parse(): turn a filter array — possibly holding FacetRange/FacetExclude
     * objects, as PHP callers pass it — back into the plain filter[] array shape, so it can be
     * JSON-encoded into a signed token and parsed again on the other side.
     *
     * @param  array<string, mixed> $filter
     * @return array<string, mixed>
     * @throws \InvalidArgumentException For a value the filter[] syntax can't express (a strict gt/lt range).
     */
    public static function serialize(array $filter): array
    {
        $out = [];
        foreach ($filter as $field => $value) {
            $out[ (string) $field] = match (true) {
                $value instanceof FacetExclude                         => ['not' => self::serializeValue($value->filter)],
                is_array($value) && array_key_exists('not', $value)    => ['not' => self::serializeValue($value['not'])],
                default                                                => self::serializeValue($value),
            };
        }
        return $out;
    }

    /**
     * Normalize a filter array PHP callers pass directly (gaffer_search()'s `filter`): values
     * that are already FacetRange/FacetExclude objects are kept as they are — including strict
     * gt/lt ranges, which the filter[] syntax can't express — and everything else is parsed
     * exactly like filter[] input.
     *
     * @param  array<string, mixed> $filter
     * @return array<string, string|list<string>|FacetRange|FacetExclude>
     */
    public static function normalize(array $filter): array
    {
        $out = [];
        foreach ($filter as $field => $value) {
            if ($value instanceof FacetRange || $value instanceof FacetExclude) {
                $name = (string) preg_replace('/[^a-z0-9_]/i', '', (string) $field);
                if ($name !== '') {
                    $out[$name] = $value;
                }
                continue;
            }
            $out += self::parse([$field => $value]);
        }
        return $out;
    }

    /** @return string|list<string>|FacetRange|null */
    private static function parseValue(mixed $value): string|array|FacetRange|null
    {
        if (!is_array($value)) {
            return is_scalar($value) && (string) $value !== '' ? (string) $value : null;
        }

        if (array_key_exists('min', $value) || array_key_exists('max', $value)) {
            $min = isset($value['min']) && is_scalar($value['min']) && $value['min'] !== '' ? (float) $value['min'] : null;
            $max = isset($value['max']) && is_scalar($value['max']) && $value['max'] !== '' ? (float) $value['max'] : null;
            return match (true) {
                $min !== null && $max !== null => FacetRange::between($min, $max),
                $min !== null                  => FacetRange::min($min),
                $max !== null                  => FacetRange::max($max),
                default                        => null,
            };
        }

        $values = array_values(array_filter(
            array_map(fn(mixed $v): string => is_scalar($v) ? (string) $v : '', $value),
            fn(string $v): bool => $v !== '',
        ));
        return match (count($values)) {
            0       => null,
            1       => $values[0],
            default => $values,
        };
    }

    private static function serializeValue(mixed $value): mixed
    {
        if ($value instanceof FacetRange) {
            if ($value->gt !== null || $value->lt !== null) {
                throw new \InvalidArgumentException('Strict FacetRange bounds (gt/lt) cannot be expressed as filter[] parameters; use min/max.');
            }
            return array_filter(['min' => $value->gte, 'max' => $value->lte], fn(?float $v): bool => $v !== null);
        }
        if (is_array($value) && (array_key_exists('min', $value) || array_key_exists('max', $value))) {
            return array_intersect_key($value, ['min' => true, 'max' => true]);
        }
        if (is_array($value)) {
            return array_values(array_map(fn(mixed $v): string => is_scalar($v) ? (string) $v : '', $value));
        }
        return is_scalar($value) ? (string) $value : '';
    }
}
