# Migration

What a theme changes when it updates the plugin. Newest first. Each entry: what changed, how
to find the affected code, what to do.

## Unreleased

### No rebuild loop with Redis

What an index was built from is now one option per index, not autoloaded (it was two
autoloaded arrays): with a persistent object cache, a long build wrote back a stale `alloptions`
and the index looked out of date after every build, so it rebuilt over and over. The old options
are moved on the first request. Nothing to change; if a site is in the loop now,
`wp cache delete alloptions options --url=<site>` once (never `wp cache flush` on a busy Redis).

### Every match of a search can be paged to

A search with words matching more than `max_docs` documents counted them all in `total` but
returned no hits past about `max_docs` (empty last pages; Fuzor). Every page up to `total` has
its hits now, sorted when a sort is asked. Nothing to change.

### Products' prices, stock, SKU and rating are built in

Every products index has `price`, `regular_price`, `sale_price` and `rating` (floats),
`stock_status` and `sku` (strings) and `on_sale`, read from WooCommerce's product objects (not
post meta, which WooCommerce may move to product tables of its own). A `meta` line for one of
them is now a problem (`doctor --wp` shows it); the engine ignores that line and uses the built-in
field, so updating the plugin before the theme changes nothing visible.

Find them: `grep -n "_price\|_regular_price\|_sale_price\|_stock_status\|_sku\|_wc_average_rating" config/search.php`

```php
// before
'meta' => [
    '_sku' => 'sku',
    '_price' => ['price', 'float'],
    '_regular_price' => ['regular_price', 'float'],
    '_sale_price' => ['sale_price', 'float'],
    '_stock_status' => 'stock_status',
    '_stock' => ['stock_quantity', 'int'],
],
// after: only what isn't built in
'meta' => [
    '_stock' => ['stock_quantity', 'int'],
],
```

Then rebuild (`wp gaffer-search rebuild`; the changed definition also rebuilds on its own) and
check `php gaffer doctor --wp`. Differences to expect: a variable product's `regular_price` and
`sale_price` are its cheapest (or default) variation's, where before they were usually missing
(WooCommerce doesn't keep them on the parent); `on_sale` is always there; `rating` and `sku` are
missing when the product has none instead of an empty string.

### A `term` lock is never dropped

A `term` (a category, brand or tag archive) whose taxonomy the index doesn't store, or that
doesn't exist, now finds nothing; before, the lock was dropped and the archive listed every
product. `doctor --wp` already warns about product taxonomies with archives the index doesn't
store: map them in `taxonomies`.

### Document `fields` that aren't numbers

A `document` closure's `int`/`float` field whose value isn't a number is left out of the
document; it was stored as `0`. Nothing to change, unless a filter relied on the 0.

### A request without definitions changes nothing

The live theme's requests no longer empty the endpoint's index list (and the schedules) while a
staged copy on `config/search.php` is built and checked: before, searches from the stage failed
with `index_unknown`. Nothing to change.

### `verify --fix`

`wp gaffer-search verify --fix` updates the documents that differ (through the update log) and
verifies again, instead of a full rebuild. Nothing to change.

### Contract 1 reset: archive URLs and SEO are Gaffer's

Before the first release, contract 1 was cut to what an engine does: `define()`, `problems()`,
`status()`, `endpoint()`, `search()`, `token()`, `supports()`. Gone: `archive()`, `url()`,
`redirect()` and the request keys `index_pages`/`indexable_filters` (Gaffer computes the canonical,
`noindex` and the redirects itself now), the response key `view`, and the feature names of
2026-11-02 (`direct_terms`, `fields`, `limits`, `facet_values`, `max_docs` are plain contract 1
now; `supports()` knows no features yet). The fixtures were recorded again. Nothing to change in
themes: update Gaffer and the plugin together.
